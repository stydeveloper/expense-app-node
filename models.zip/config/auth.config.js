module.exports = {
    secret: "expense-secret-key"
}