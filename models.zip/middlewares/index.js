const headerJwt = require('./headerJwt');

module.exports = {
    headerJwt
}